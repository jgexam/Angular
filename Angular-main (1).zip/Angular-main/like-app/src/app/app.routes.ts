import { RouterLink, Routes } from '@angular/router';
import { ImageComponent } from './image/image.component';

export const routes: Routes = [
    
    
];
