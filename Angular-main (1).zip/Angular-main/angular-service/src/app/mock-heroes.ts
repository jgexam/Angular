import { Hero } from './hero';

export const HEROES: Hero[] = [
  { id: 12, name: 'Dr. Pushpalata' },
  { id: 13, name: 'Prof.Jaydeep' },
  { id: 14, name: 'Prof.Neel' },
  { id: 15, name: 'Prof.Shreyas' },
  { id: 16, name: 'Prof.Sanjana' },
  { id: 17, name: 'Prof.Menka' },
  { id: 18, name: 'Prof.Menka' },
  { id: 19, name: 'Prof.Shreya' },
  { id: 20, name: 'Prof.Meenaxi' },
  {id:22,name:'Prof.Janvi'}
];


